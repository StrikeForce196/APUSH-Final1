// Main shared JavaScript for APUSH Learning Hub
// Handles navigation, theme toggle, and common functionality

// Initialize on DOM load
document.addEventListener('DOMContentLoaded', () => {
    if (typeof window.AuthManager !== 'undefined' && typeof window.AuthManager.init === 'function') {
        window.AuthManager.init();
    }
    applyGlobalAccessibility();
    initNavigation();
    initThemeToggle();
    initLiquidGlassSystem();
    initModals();
    setTimeout(() => {
        if (typeof updateNavigation === 'function') updateNavigation();
    }, 100);
    // Re-apply when Supabase restores session asynchronously
    window.addEventListener('apush:session-restored', () => {
        applyGlobalAccessibility();
        if (typeof updateNavigation === 'function') updateNavigation();
    });
});

// Apply reduced motion, high contrast, font size, primary hue globally (guest + auth)
function applyGlobalAccessibility() {
    const isAuth = window.AuthManager && window.AuthManager.isAuthenticated();
    let reducedMotion = false, highContrast = false, fontSize = 'medium', primaryHue = 217;
    if (isAuth) {
        const s = window.AuthManager.getCurrentUserSettings();
        if (s) {
            reducedMotion = s.reducedMotion || false;
            highContrast = s.highContrast || false;
            fontSize = s.fontSize || 'medium';
            primaryHue = s.primaryHue !== undefined ? s.primaryHue : 217;
        }
    } else {
        // Guests get non-persistent defaults.
        reducedMotion = false;
        highContrast = false;
        fontSize = 'medium';
        primaryHue = 217;
    }
    if (reducedMotion) document.documentElement.setAttribute('data-reduced-motion', 'true');
    else document.documentElement.removeAttribute('data-reduced-motion');
    if (highContrast) document.documentElement.setAttribute('data-high-contrast', 'true');
    else document.documentElement.removeAttribute('data-high-contrast');
    document.documentElement.setAttribute('data-font-size', fontSize || 'medium');
    document.documentElement.style.setProperty('--primary-color', `hsl(${primaryHue}, 70%, 50%)`);
    document.documentElement.style.setProperty('--primary-hover', `hsl(${primaryHue}, 70%, 40%)`);
}

// Navigation functionality
function initNavigation() {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');
    
    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', !isExpanded);
            navMenu.classList.toggle('active');
        });
    }
}

// Theme toggle (Dark mode)
function initThemeToggle() {
    const themeToggle = document.querySelector('.theme-toggle');
    const themeIcon = document.querySelector('.theme-icon');
    const guestThemeKey = 'apush_guest_theme';
    
    // Check for user settings if authenticated; guests use non-persistent default.
    let currentTheme = 'light';
    if (window.AuthManager && window.AuthManager.isAuthenticated()) {
        const settings = window.AuthManager.getCurrentUserSettings();
        if (settings && settings.theme) {
            if (settings.theme === 'system') {
                const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
                currentTheme = prefersDark ? 'dark' : 'light';
            } else {
                currentTheme = settings.theme;
            }
        }
    } else {
        const sessionTheme = sessionStorage.getItem(guestThemeKey);
        if (sessionTheme === 'light' || sessionTheme === 'dark') {
            currentTheme = sessionTheme;
        }
    }
    
    document.documentElement.setAttribute('data-theme', currentTheme);
    updateThemeIcon(currentTheme, themeIcon);
    
    if (themeToggle) {
        themeToggle.addEventListener('click', () => {
            const currentTheme = document.documentElement.getAttribute('data-theme');
            const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
            
            document.documentElement.setAttribute('data-theme', newTheme);
            
            // Save only for authenticated users.
            if (window.AuthManager && window.AuthManager.isAuthenticated()) {
                window.AuthManager.updateSetting('theme', newTheme);
            } else {
                // Keep guest theme consistent across pages for this browsing session only.
                sessionStorage.setItem(guestThemeKey, newTheme);
            }
            
            updateThemeIcon(newTheme, themeIcon);
        });
    }
}

function updateThemeIcon(theme, iconElement) {
    if (iconElement) {
        iconElement.textContent = theme === 'dark' ? '☀️' : '🌙';
    }
}

// Liquid glass switcher + card styling system
function initLiquidGlassSystem() {
    const fallbackStyle = 'classic';
    const styleOptions = ['classic', 'dark', 'aurora'];

    let currentStyle = fallbackStyle;
    if (window.AuthManager && window.AuthManager.isAuthenticated()) {
        const settings = window.AuthManager.getCurrentUserSettings();
        if (settings && styleOptions.includes(settings.liquidGlassStyle)) {
            currentStyle = settings.liquidGlassStyle;
        }
    }

    applyLiquidGlassStyle(currentStyle);
    createLiquidGlassSwitcher(currentStyle);
    applyLiquidGlassTargets();

    // Re-apply to dynamic content (resources, sessions, modal-generated blocks)
    const observer = new MutationObserver(() => {
        applyLiquidGlassTargets();
    });
    observer.observe(document.body, { childList: true, subtree: true });
}

function createLiquidGlassSwitcher(currentStyle) {
    if (document.querySelector('.liquid-glass-switcher')) return;

    const switcher = document.createElement('fieldset');
    switcher.className = 'liquid-glass-switcher';
    switcher.setAttribute('aria-label', 'Liquid glass style');

    switcher.innerHTML = `
        <legend class="liquid-glass-switcher__legend">Visual style</legend>
        <label class="liquid-glass-switcher__option">
            <input class="liquid-glass-switcher__input" type="radio" name="liquid-glass-style" value="classic">
            <span class="liquid-glass-switcher__icon" aria-hidden="true">☀️</span>
        </label>
        <label class="liquid-glass-switcher__option">
            <input class="liquid-glass-switcher__input" type="radio" name="liquid-glass-style" value="dark">
            <span class="liquid-glass-switcher__icon" aria-hidden="true">🌙</span>
        </label>
        <label class="liquid-glass-switcher__option">
            <input class="liquid-glass-switcher__input" type="radio" name="liquid-glass-style" value="aurora">
            <span class="liquid-glass-switcher__icon" aria-hidden="true">✨</span>
        </label>
    `;

    document.body.appendChild(switcher);
    bindLiquidGlassSwitcher(switcher, currentStyle);
}

function bindLiquidGlassSwitcher(switcher, currentStyle) {
    const radios = Array.from(switcher.querySelectorAll('input[type="radio"]'));
    const selected = radios.find(radio => radio.value === currentStyle) || radios[0];
    if (selected) {
        selected.checked = true;
    }

    const setActivePosition = (value) => {
        const index = Math.max(0, radios.findIndex(radio => radio.value === value));
        switcher.style.setProperty('--liquid-active-index', String(index));
    };

    setActivePosition(currentStyle);

    radios.forEach(radio => {
        radio.addEventListener('change', () => {
            if (!radio.checked) return;
            setActivePosition(radio.value);
            applyLiquidGlassStyle(radio.value);

            if (window.AuthManager && window.AuthManager.isAuthenticated()) {
                window.AuthManager.updateSetting('liquidGlassStyle', radio.value);
            }
        });
    });
}

function applyLiquidGlassStyle(style) {
    document.documentElement.setAttribute('data-glass-style', style);
}

function applyLiquidGlassTargets() {
    const glassSelectors = [
        '.readiness-card',
        '.action-card',
        '.feature-card',
        '.challenge-card',
        '.metrics-results',
        '.metrics-form',
        '.stat-item',
        '.dashboard-card',
        '.calendar-container',
        '.session-card',
        '.resource-card',
        '.unit-card',
        '.modal-content',
        '.theme-toggle',
        '.settings-gear-btn'
    ];

    document.querySelectorAll(glassSelectors.join(',')).forEach(element => {
        element.classList.add('liquid-glass');
    });
}

// Reduced motion, high contrast now in Unified Settings Modal (gear)

// Modal functionality
function initModals() {
    const modals = document.querySelectorAll('.modal');
    const modalCloses = document.querySelectorAll('.modal-close');
    
    modals.forEach(modal => {
        // Close on background click
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                closeModal(modal);
            }
        });
        
        // Close on Escape key
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && modal.classList.contains('active')) {
                closeModal(modal);
            }
        });
    });
    
    modalCloses.forEach(closeBtn => {
        closeBtn.addEventListener('click', () => {
            const modal = closeBtn.closest('.modal');
            if (modal) {
                closeModal(modal);
            }
        });
    });
}

function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.add('active');
        modal.setAttribute('aria-hidden', 'false');
        // Focus first focusable element
        const firstFocusable = modal.querySelector('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])');
        if (firstFocusable) {
            firstFocusable.focus();
        }
    }
}

function closeModal(modal) {
    if (modal) {
        modal.classList.remove('active');
        modal.setAttribute('aria-hidden', 'true');
    }
}

// Utility function to get user progress from localStorage
// Uses user-specific key if authenticated, otherwise falls back to global
function getUserProgress() {
    let progressKey = null;
    try {
        if (window.AuthManager && typeof window.AuthManager.isAuthenticated === 'function' && window.AuthManager.isAuthenticated()) {
            const currentUser = window.AuthManager.getCurrentUser();
            if (currentUser && currentUser.id) {
                progressKey = `user_${currentUser.id}_progress`;
            }
        }
    } catch (e) {
        console.debug('AuthManager not ready, returning guest defaults');
    }

    if (!progressKey) {
        return {
            periods: {},
            skills: {},
            practiceQuestions: 0,
            studyHours: 0,
            activities: []
        };
    }

    try {
        const progress = localStorage.getItem(progressKey);
        return progress ? JSON.parse(progress) : {
            periods: {},
            skills: {},
            practiceQuestions: 0,
            studyHours: 0,
            activities: []
        };
    } catch (e) {
        console.error('Failed to parse progress data:', e);
        return {
            periods: {},
            skills: {},
            practiceQuestions: 0,
            studyHours: 0,
            activities: []
        };
    }
}

// Utility function to save user progress
// Uses user-specific key if authenticated, otherwise falls back to global
function saveUserProgress(progress) {
    let progressKey = null;
    try {
        if (window.AuthManager && typeof window.AuthManager.isAuthenticated === 'function' && window.AuthManager.isAuthenticated()) {
            const currentUser = window.AuthManager.getCurrentUser();
            if (currentUser && currentUser.id) {
                progressKey = `user_${currentUser.id}_progress`;
            }
        }
    } catch (e) {
        console.debug('AuthManager not ready, skipping save');
    }

    if (!progressKey) {
        // Explicitly do not persist guest data.
        return false;
    }
    
    try {
        localStorage.setItem(progressKey, JSON.stringify(progress));
        if (window.SupabasePersistence && window.SupabasePersistence.isReady()) {
            const currentUser = window.AuthManager && window.AuthManager.getCurrentUser ? window.AuthManager.getCurrentUser() : null;
            if (currentUser && currentUser.id) {
                window.SupabasePersistence.pushProgress(currentUser.id, progress);
            }
        }
    } catch (e) {
        console.error('Failed to save progress:', e);
        // Try to clear space if quota exceeded
        if (e.name === 'QuotaExceededError') {
            alert('Storage quota exceeded. Please clear some data.');
        }
    }
    return true;
}

// Utility function to update progress
function updateProgress(period, skill, value) {
    const progress = getUserProgress();
    
    if (!progress.periods[period]) {
        progress.periods[period] = { mastery: 0, completed: false };
    }
    
    if (skill) {
        if (!progress.skills[skill]) {
            progress.skills[skill] = 0;
        }
        progress.skills[skill] = value;
    }
    
    saveUserProgress(progress);
    return progress;
}

// Calculate overall mastery percentage
function calculateOverallMastery() {
    const progress = getUserProgress();
    const periods = Object.keys(progress.periods);
    
    if (periods.length === 0) return 0;
    
    const totalMastery = periods.reduce((sum, period) => {
        return sum + (progress.periods[period].mastery || 0);
    }, 0);
    
    return Math.round(totalMastery / periods.length);
}

// Format date for display
function formatDate(date) {
    return new Date(date).toLocaleDateString('en-US', {
        weekday: 'short',
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    });
}

// Format time for display
function formatTime(date) {
    return new Date(date).toLocaleTimeString('en-US', {
        hour: 'numeric',
        minute: '2-digit'
    });
}

// Export functions for use in other scripts
window.APUSH = {
    openModal,
    closeModal,
    getUserProgress,
    saveUserProgress,
    updateProgress,
    calculateOverallMastery,
    formatDate,
    formatTime
};
