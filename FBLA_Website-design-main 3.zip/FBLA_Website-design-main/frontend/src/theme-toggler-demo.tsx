import { AnimatedThemeToggler } from "@/components/ui/animated-theme-toggler"

export default function ThemeTogglerDemo() {
  return (
    <div className="flex min-h-[200px] w-full items-center justify-center">
      <AnimatedThemeToggler />
    </div>
  )
}
