import LandingDemo from "./landing-demo"

/** Vite dev preview — homepage intro (GLSL hills + APUSH HUB). */
export default function DemoOne() {
  return <LandingDemo />
}
