/**
 * Mounts AnimatedThemeToggler into static HTML pages (#theme-toggler-root).
 * Build: npm run build:theme → ../theme-toggler.js
 */
import { StrictMode } from "react"
import { createRoot } from "react-dom/client"
import { AnimatedThemeToggler } from "@/components/ui/animated-theme-toggler"

const GUEST_THEME_KEY = "apush_guest_theme"

function persistTheme(theme: "light" | "dark") {
  if (window.AuthManager && window.AuthManager.isAuthenticated()) {
    window.AuthManager.updateSetting("theme", theme)
  } else {
    sessionStorage.setItem(GUEST_THEME_KEY, theme)
  }
}

function mountThemeToggler() {
  const roots = document.querySelectorAll<HTMLElement>("[data-theme-toggler-root]")
  roots.forEach(el => {
    if (el.dataset.themeTogglerMounted === "true") return
    el.dataset.themeTogglerMounted = "true"
    createRoot(el).render(
      <StrictMode>
        <AnimatedThemeToggler onThemeChange={persistTheme} />
      </StrictMode>
    )
  })
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", mountThemeToggler)
} else {
  mountThemeToggler()
}

declare global {
  interface Window {
    AuthManager?: {
      isAuthenticated: () => boolean
      updateSetting: (key: string, value: string) => void
    }
  }
}
