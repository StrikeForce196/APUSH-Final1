import { GLSLHills } from "@/components/ui/glsl-hills"

export default function LandingDemo() {
  return (
    <div className="relative flex h-screen w-full flex-col items-center justify-center overflow-hidden bg-[#050508]">
      <GLSLHills width="100%" height="100%" className="absolute inset-0" />
      <div className="pointer-events-none absolute inset-0 z-[2] bg-[radial-gradient(ellipse_80%_60%_at_50%_45%,transparent_0%,rgba(5,5,8,0.85)_100%)]" />
      <div className="pointer-events-none relative z-10 space-y-6 px-6 text-center">
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-primary">
          AP U.S. History
        </p>
        <h1 className="text-5xl font-bold tracking-wide md:text-7xl">APUSH HUB</h1>
        <p className="mx-auto max-w-md text-sm text-muted-foreground">
          An interactive study platform with period mastery, DBQ tools, live
          sessions, and evidence-based APUSH resources.
        </p>
      </div>
    </div>
  )
}
