import path from "path"
import react from "@vitejs/plugin-react"
import { defineConfig } from "vite"

/** Builds the theme toggler widget for static HTML pages (../theme-toggler.js). */
export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
  build: {
    outDir: path.resolve(__dirname, ".."),
    emptyOutDir: false,
    lib: {
      entry: path.resolve(__dirname, "src/theme-toggler-mount.tsx"),
      name: "ApushThemeToggler",
      formats: ["es"],
      fileName: () => "theme-toggler",
    },
    rollupOptions: {
      output: {
        inlineDynamicImports: true,
      },
    },
  },
})
