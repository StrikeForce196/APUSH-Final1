# Frontend (shadcn + Tailwind + TypeScript)

The `frontend/` folder is a Vite + React + TypeScript app aligned with [shadcn/ui](https://ui.shadcn.com) conventions.

## Default paths

| Item | Path |
|------|------|
| UI components | `frontend/src/components/ui/` |
| Global styles | `frontend/src/index.css` |
| Utils (`cn`) | `frontend/src/lib/utils.ts` |
| shadcn aliases | `@/components/ui/*` (see `components.json`) |

shadcn expects `components/ui` so CLI installs stay consistent and imports match the docs.

## First-time setup

```bash
cd frontend
npm install
```

## Animated theme toggler (navbar)

Component: `src/components/ui/animated-theme-toggler.tsx`  
Demo: `src/theme-toggler-demo.tsx`  
Static-site mount: `src/theme-toggler-mount.tsx`

Dependency (already in `package.json`):

```bash
npm install motion
```

The static site uses **`../theme-toggler.js`** (vanilla JS, no build required) with styles in **`../theme-toggler.css`**.

Optional React build (same filename; only if you prefer the `motion/react` version):

```bash
npm run build:theme
```

The navbar mount point is `[data-theme-toggler-root]` on every main page.

## GLSL hills intro (homepage)

Component: `src/components/ui/glsl-hills.tsx`  
Landing demo: `src/landing-demo.tsx`

The live site (`index.html`) shows a full-screen intro with animated hills and **APUSH HUB** before the main app. Uses Three.js via import map + `glsl-hills.js` / `intro-splash.js` (no build required).

Guests see the hills intro until they sign in. **Sign In** goes to `login.html`; after login, `index.html` shows the full app. Other pages redirect guests to `index.html` via `auth-guard.js`.

## Dev preview (Vite)

```bash
npm run dev
```

## New shadcn components

From `frontend/`:

```bash
npx shadcn@latest add button
```

Ensure `components.json` exists (it does) and Tailwind is wired via `@tailwindcss/vite` in `vite.config.ts`.
