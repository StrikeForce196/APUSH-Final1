import { WEBP_DISPLACEMENT_MAP } from "./tahoe-displacement-map.js";

function prefersReducedMotion() {
  return (
    window.matchMedia("(prefers-reduced-motion: reduce)").matches ||
    document.documentElement.getAttribute("data-reduced-motion") === "true"
  );
}

function createFilterDefs(container, filterId) {
  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute("aria-hidden", "true");
  svg.classList.add("tahoe-glass-defs");
  svg.style.cssText = "position:absolute;width:0;height:0;overflow:hidden;pointer-events:none";

  svg.innerHTML = `
    <filter id="${filterId}" primitiveUnits="objectBoundingBox">
      <feImage result="map" width="100%" height="100%" x="0" y="0" href="${WEBP_DISPLACEMENT_MAP}" preserveAspectRatio="none" />
      <feGaussianBlur in="SourceGraphic" stdDeviation="0.01" result="blur" />
      <feDisplacementMap in="blur" in2="map" scale="0.5" xChannelSelector="R" yChannelSelector="G" />
    </filter>
  `;

  container.appendChild(svg);
}

function wrapLinkAsTahoeButton(link) {
  if (link.querySelector(".tahoe-glass-btn__lens")) return;

  const label = link.textContent.trim();
  link.textContent = "";
  link.classList.add("tahoe-glass-btn");

  const lens = document.createElement("span");
  lens.className = "tahoe-glass-btn__lens";
  lens.setAttribute("aria-hidden", "true");

  const text = document.createElement("span");
  text.className = "tahoe-glass-btn__text";
  text.textContent = label;

  link.append(lens, text);
}

export function initTahoeGlassButtons(root = document) {
  const buttons = root.querySelectorAll(
    ".tahoe-glass-btn, a.liquid-glass-btn, .hero-cta-row a"
  );

  if (!buttons.length) return;

  const defsHost =
    document.getElementById("tahoe-glass-defs-host") ||
    (() => {
      const host = document.createElement("div");
      host.id = "tahoe-glass-defs-host";
      host.hidden = true;
      document.body.appendChild(host);
      return host;
    })();

  buttons.forEach((el, index) => {
    if (el.tagName === "A") wrapLinkAsTahoeButton(el);
    el.classList.remove("liquid-glass-btn", "liquid-glass-btn--primary");

    const filterId = `tahoe-liquid-glass-${index}`;
    if (!defsHost.querySelector(`#${filterId}`)) {
      createFilterDefs(defsHost, filterId);
    }

    const lens = el.querySelector(".tahoe-glass-btn__lens");
    if (lens) {
      if (prefersReducedMotion()) {
        lens.style.backdropFilter = "blur(8px) saturate(150%)";
        lens.style.webkitBackdropFilter = "blur(8px) saturate(150%)";
      } else {
        const filterValue = `blur(8px) url(#${filterId}) saturate(150%)`;
        lens.style.backdropFilter = filterValue;
        lens.style.webkitBackdropFilter = "blur(8px) saturate(150%)";
      }
    }
  });
}

document.addEventListener("DOMContentLoaded", () => {
  initTahoeGlassButtons();
});
