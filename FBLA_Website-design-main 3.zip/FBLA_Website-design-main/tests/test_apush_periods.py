"""Ensure period filters stay aligned with apush-data.js."""

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def _period_keys_from_apush_data() -> list[int]:
    text = (ROOT / "apush-data.js").read_text(encoding="utf-8")
    block = re.search(r"periods:\s*\{", text)
    if not block:
        raise AssertionError("apush-data.js: periods block not found")
    start = block.end()
    depth = 1
    i = start
    while i < len(text) and depth:
        if text[i] == "{":
            depth += 1
        elif text[i] == "}":
            depth -= 1
        i += 1
    section = text[start : i - 1]
    return sorted(int(m.group(1)) for m in re.finditer(r"^\s+(\d+):\s*\{", section, re.MULTILINE))


def test_apush_data_has_periods_one_through_eight():
    keys = _period_keys_from_apush_data()
    assert keys == list(range(1, 9))
