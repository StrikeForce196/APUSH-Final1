/**
 * Scroll-reveal for museum sections. Respects prefers-reduced-motion and data-reduced-motion.
 */
(function () {
  function motionAllowed() {
    if (document.documentElement.getAttribute("data-reduced-motion") === "true") return false;
    return !window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  }

  function initReveal() {
    const nodes = document.querySelectorAll(".reveal:not(.reveal-visible)");
    if (!nodes.length) return;

    if (!motionAllowed()) {
      nodes.forEach((el) => el.classList.add("reveal-visible"));
      return;
    }

    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("reveal-visible");
            io.unobserve(entry.target);
          }
        });
      },
      { root: null, rootMargin: "0px 0px -8% 0px", threshold: 0.12 }
    );

    nodes.forEach((el) => io.observe(el));
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initReveal);
  } else {
    initReveal();
  }
})();
