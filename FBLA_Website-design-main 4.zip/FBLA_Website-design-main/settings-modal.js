/**
 * Unified Settings Modal
 * Opened by the gear button in nav. Contains General, AI Config, Account & Data.
 */
(function() {
    const MODAL_ID = 'unified-settings-modal';

    function createModalHTML() {
        return `
<div class="modal" id="${MODAL_ID}" role="dialog" aria-labelledby="settings-modal-title" aria-hidden="true">
    <div class="modal-content settings-modal-content">
        <div class="modal-header">
            <h2 id="settings-modal-title" class="modal-title">Settings</h2>
            <button class="modal-close" aria-label="Close settings">&times;</button>
        </div>
        <div class="settings-modal-body">
            <nav class="settings-modal-sidebar" role="tablist">
                <button class="settings-tab-btn active" data-tab="general" role="tab">General & Accessibility</button>
                <button class="settings-tab-btn" data-tab="ai" role="tab">AI Configuration</button>
                <button class="settings-tab-btn" data-tab="account" role="tab">Account & Data</button>
            </nav>
            <div class="settings-modal-panels">
                <!-- General & Accessibility -->
                <div class="settings-panel active" id="panel-general" role="tabpanel">
                    <h3>General & Accessibility</h3>
                    <p class="settings-panel-desc">Adjust accessibility features to suit your needs.</p>
                    <div class="setting-item">
                        <div class="setting-label">
                            <div class="setting-title">Theme Color</div>
                            <div class="setting-description">Choose your accent color (hue)</div>
                        </div>
                        <input type="range" id="theme-hue-slider" class="theme-hue-slider" min="0" max="360" value="217" aria-label="Theme color hue">
                        <p class="theme-hue-value"><span id="theme-hue-display">217</span>°</p>
                    </div>
                    <div class="setting-item">
                        <div class="setting-label">
                            <div class="setting-title">Reduced Motion</div>
                            <div class="setting-description">Reduce animations and transitions</div>
                        </div>
                        <div class="toggle-switch" id="modal-reduced-motion" role="switch" aria-checked="false"></div>
                    </div>
                    <div class="setting-item">
                        <div class="setting-label">
                            <div class="setting-title">Font Size</div>
                            <div class="setting-description">Adjust the base font size</div>
                        </div>
                        <select id="modal-font-size" class="select-control">
                            <option value="small">Small</option>
                            <option value="medium" selected>Medium</option>
                            <option value="large">Large</option>
                        </select>
                    </div>
                    <div class="setting-item">
                        <div class="setting-label">
                            <div class="setting-title">High Contrast Mode</div>
                            <div class="setting-description">Increase contrast for better visibility</div>
                        </div>
                        <div class="toggle-switch" id="modal-high-contrast" role="switch" aria-checked="false"></div>
                    </div>
                    <div class="setting-item">
                        <div class="setting-label">
                            <div class="setting-title">Clear Local Data</div>
                            <div class="setting-description">Remove saved preferences and progress from this device</div>
                        </div>
                        <button type="button" class="btn-secondary" id="modal-clear-data">Clear</button>
                    </div>
                </div>
                <!-- AI Configuration -->
                <div class="settings-panel" id="panel-ai" role="tabpanel">
                    <h3>AI (ChatGPT)</h3>
                    <p class="settings-panel-desc">Practice questions and essay grading use OpenAI on the server. No API key is stored in the browser.</p>
                    <div class="setting-item">
                        <p class="config-description">Run <code style="font-size:0.9em;">python app.py</code> and set the <code style="font-size:0.9em;">OPENAI_API_KEY</code> environment variable on the machine hosting the site.</p>
                    </div>
                    <div class="config-status" id="modal-api-status">Status: Checking…</div>
                    <div class="config-actions">
                        <button type="button" class="submit-btn" id="modal-refresh-ai-status">Refresh status</button>
                        <button type="button" class="submit-btn" id="modal-test-api-key">Test AI</button>
                    </div>
                </div>
                <!-- Account & Data -->
                <div class="settings-panel" id="panel-account" role="tabpanel">
                    <h3>Account & Data</h3>
                    <p class="settings-panel-desc" id="account-desc">Manage your account and export data.</p>
                    <div id="account-guest-state">
                        <p>Sign in to sync settings and progress across devices.</p>
                        <a href="login.html" class="submit-btn" style="display:inline-block;text-decoration:none;text-align:center;margin-top:0.5rem;">Sign In</a>
                    </div>
                    <div id="account-auth-state" style="display:none;">
                        <div class="setting-item">
                            <div class="setting-label">
                                <div class="setting-title">Email</div>
                                <div class="account-email" id="modal-account-email"></div>
                            </div>
                        </div>
                        <div class="setting-item">
                            <div class="setting-label">
                                <div class="setting-title">Export All User Data</div>
                                <div class="setting-description">Download progress, settings, and history as JSON</div>
                            </div>
                            <button type="button" class="btn-secondary" id="modal-export-data">Export</button>
                        </div>
                        <div class="setting-item">
                            <div class="setting-label">
                                <div class="setting-title">Log Out</div>
                                <div class="setting-description">Sign out of your account</div>
                            </div>
                            <button type="button" class="btn-danger" id="modal-logout">Log Out</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>`;
    }

    function getSettings() {
        const isAuth = window.AuthManager && window.AuthManager.isAuthenticated();
        if (isAuth) {
            const s = window.AuthManager.getCurrentUserSettings();
            return s || {};
        }
        // Guests use temporary defaults only (no local persistence).
        return {
            theme: 'light',
            reducedMotion: false,
            fontSize: 'medium',
            highContrast: false,
            primaryHue: 217
        };
    }

    function saveSetting(key, value) {
        if (window.AuthManager && window.AuthManager.isAuthenticated()) {
            window.AuthManager.updateSetting(key, value);
        }
    }

    function applyPrimaryHue(hue) {
        document.documentElement.style.setProperty('--primary-color', `hsl(${hue}, 70%, 50%)`);
        document.documentElement.style.setProperty('--primary-hover', `hsl(${hue}, 70%, 40%)`);
    }

    function initModal() {
        if (document.getElementById(MODAL_ID)) return;

        document.body.insertAdjacentHTML('beforeend', createModalHTML());
        const modal = document.getElementById(MODAL_ID);

        // Tab switching
        document.querySelectorAll('.settings-tab-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                document.querySelectorAll('.settings-tab-btn').forEach(b => b.classList.remove('active'));
                document.querySelectorAll('.settings-panel').forEach(p => p.classList.remove('active'));
                btn.classList.add('active');
                const tab = btn.dataset.tab;
                const panel = document.getElementById('panel-' + tab);
                if (panel) panel.classList.add('active');
            });
        });

        // Close
        modal.querySelector('.modal-close').addEventListener('click', () => closeModal(modal));
        modal.addEventListener('click', (e) => { if (e.target === modal) closeModal(modal); });
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && modal.classList.contains('active')) closeModal(modal);
        });

        // Theme Hue Slider
        const hueSlider = document.getElementById('theme-hue-slider');
        const hueDisplay = document.getElementById('theme-hue-display');
        const settings = getSettings();
        const hue = settings.primaryHue !== undefined ? settings.primaryHue : 217;
        hueSlider.value = hue;
        hueDisplay.textContent = hue;
        applyPrimaryHue(hue);

        hueSlider.style.background = `linear-gradient(to right, red, yellow, lime, cyan, blue, magenta, red)`;
        hueSlider.addEventListener('input', () => {
            const v = parseInt(hueSlider.value, 10);
            hueDisplay.textContent = v;
            applyPrimaryHue(v);
            saveSetting('primaryHue', v);
        });

        // Reduced Motion
        const rmToggle = document.getElementById('modal-reduced-motion');
        rmToggle.classList.toggle('active', settings.reducedMotion || false);
        rmToggle.setAttribute('aria-checked', settings.reducedMotion || false);
        rmToggle.addEventListener('click', function() {
            const active = !this.classList.contains('active');
            this.classList.toggle('active', active);
            this.setAttribute('aria-checked', active);
            document.documentElement.setAttribute('data-reduced-motion', active ? 'true' : 'false');
            saveSetting('reducedMotion', active);
        });

        // Font Size
        const fontSizeSelect = document.getElementById('modal-font-size');
        fontSizeSelect.value = settings.fontSize || 'medium';
        fontSizeSelect.addEventListener('change', (e) => {
            const v = e.target.value;
            document.documentElement.setAttribute('data-font-size', v || 'medium');
            saveSetting('fontSize', v);
        });

        // High Contrast
        const hcToggle = document.getElementById('modal-high-contrast');
        hcToggle.classList.toggle('active', settings.highContrast || false);
        hcToggle.setAttribute('aria-checked', settings.highContrast || false);
        hcToggle.addEventListener('click', function() {
            const active = !this.classList.contains('active');
            this.classList.toggle('active', active);
            this.setAttribute('aria-checked', active);
            document.documentElement.setAttribute('data-high-contrast', active ? 'true' : 'false');
            saveSetting('highContrast', active);
        });

        // Clear Data
        document.getElementById('modal-clear-data').addEventListener('click', () => {
            if (confirm('Clear all local preferences and progress from this device?')) {
                localStorage.removeItem('theme');
                localStorage.removeItem('reducedMotion');
                localStorage.removeItem('fontSize');
                localStorage.removeItem('highContrast');
                localStorage.removeItem('primaryHue');
                localStorage.removeItem('userProgress');
                const user = window.AuthManager && window.AuthManager.getCurrentUser ? window.AuthManager.getCurrentUser() : null;
                if (user && user.id) {
                    localStorage.removeItem(`user_${user.id}_progress`);
                    localStorage.removeItem(`user_${user.id}_settings`);
                }
                document.documentElement.removeAttribute('data-high-contrast');
                document.documentElement.removeAttribute('data-font-size');
                document.documentElement.removeAttribute('data-reduced-motion');
                document.documentElement.style.removeProperty('--primary-color');
                document.documentElement.style.removeProperty('--primary-hover');
                alert('Local data cleared. Refreshing.');
                location.reload();
            }
        });

        // AI (server OpenAI)
        function updateAiStatusUi() {
            const apiStatus = document.getElementById('modal-api-status');
            if (!apiStatus || !window.OpenAIAPI) return;
            if (window.OpenAIAPI.hasApiKey()) {
                apiStatus.textContent = 'Status: ✓ Server AI available';
                apiStatus.style.color = 'var(--success-color)';
            } else {
                apiStatus.textContent = 'Status: Server AI unavailable (run python app.py with OPENAI_API_KEY)';
                apiStatus.style.color = 'var(--text-secondary)';
            }
        }
        if (window.OpenAIAPI) {
            window.OpenAIAPI.refreshAiStatus().then(updateAiStatusUi);
            const refreshBtn = document.getElementById('modal-refresh-ai-status');
            if (refreshBtn) {
                refreshBtn.addEventListener('click', async () => {
                    await window.OpenAIAPI.refreshAiStatus();
                    updateAiStatusUi();
                });
            }
            const testApiBtn = document.getElementById('modal-test-api-key');
            if (testApiBtn) testApiBtn.addEventListener('click', async () => {
                try {
                    await window.OpenAIAPI.refreshAiStatus();
                    const q = await window.OpenAIAPI.generateMCQ({
                        number: 3,
                        name: 'Revolution and Early Republic',
                        dates: '1754-1800',
                        themes: ['American Revolution', 'Constitution']
                    });
                    updateAiStatusUi();
                    alert(q ? '✓ OpenAI connection successful' : 'Generation failed — check server logs and OPENAI_API_KEY');
                } catch (e) {
                    alert('✗ ' + (e.message || String(e)));
                }
            });
            window._updateAiStatusUi = updateAiStatusUi;
        }

        // Account: Export, Logout
        function refreshAccountState() {
            const isAuth = window.AuthManager && window.AuthManager.isAuthenticated();
            document.getElementById('account-guest-state').style.display = isAuth ? 'none' : 'block';
            document.getElementById('account-auth-state').style.display = isAuth ? 'block' : 'none';
            if (isAuth) {
                const info = window.AuthManager.getUserInfo();
                document.getElementById('modal-account-email').textContent = info.email;
            }
        }

        document.getElementById('modal-export-data').addEventListener('click', () => {
            const progress = window.APUSH ? window.APUSH.getUserProgress() : {};
            const settings = getSettings();
            const blob = new Blob([JSON.stringify({ progress, settings, exportedAt: new Date().toISOString() }, null, 2)], { type: 'application/json' });
            const a = document.createElement('a');
            a.href = URL.createObjectURL(blob);
            a.download = 'apush-data-' + new Date().toISOString().slice(0, 10) + '.json';
            a.click();
            URL.revokeObjectURL(a.href);
        });

        document.getElementById('modal-logout').addEventListener('click', () => {
            if (confirm('Log out?')) window.AuthManager.logout();
        });

        refreshAccountState();
        window._refreshSettingsAccount = refreshAccountState;
    }

    function openModal() {
        initModal();
        const modal = document.getElementById(MODAL_ID);
        modal.classList.add('active');
        modal.setAttribute('aria-hidden', 'false');
        if (window._refreshSettingsAccount) window._refreshSettingsAccount();
        if (window.OpenAIAPI && window._updateAiStatusUi) {
            window.OpenAIAPI.refreshAiStatus().then(window._updateAiStatusUi);
        }
        const first = modal.querySelector('button, input, select');
        if (first) first.focus();
    }

    function closeModal(modal) {
        if (modal) {
            modal.classList.remove('active');
            modal.setAttribute('aria-hidden', 'true');
        }
    }

    window.openUnifiedSettings = openModal;

    document.addEventListener('DOMContentLoaded', () => {
        initModal();
        const s = getSettings();
        const hue = s.primaryHue !== undefined ? s.primaryHue : 217;
        applyPrimaryHue(hue);
        document.querySelectorAll('.settings-gear-btn').forEach(btn => {
            btn.addEventListener('click', openModal);
        });
        window.addEventListener('apush:session-restored', () => {
            if (window._refreshSettingsAccount) window._refreshSettingsAccount();
        });
    });
})();
