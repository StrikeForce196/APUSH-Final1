/**
 * Organized catalog of pre-built DBQ / LEQ / SAQ / supplemental questions.
 */
document.addEventListener("DOMContentLoaded", () => {
  const root = document.getElementById("question-bank-root");
  if (!root || !window.APUSH_PROMPT_BANK) return;

  const bank = window.APUSH_PROMPT_BANK;
  const tabs = root.querySelectorAll("[data-bank-tab]");
  const panels = root.querySelectorAll("[data-bank-panel]");
  const search = document.getElementById("question-bank-search");

  function escapeHtml(v) {
    const d = document.createElement("div");
    d.textContent = String(v ?? "");
    return d.innerHTML;
  }

  function renderDbqCard(item) {
    const sources = (item.sources || []).slice(0, 6);
    return `
      <article class="qb-card qb-card--dbq" data-period="${item.period}">
        <header class="qb-card__head">
          <span class="qb-card__badge">Period ${escapeHtml(item.period)}</span>
          <span class="qb-card__id">${escapeHtml(item.id)}</span>
        </header>
        <h3 class="qb-card__title">${escapeHtml(item.label || "Document-Based Question")}</h3>
        <p class="qb-card__prompt">${escapeHtml(item.prompt)}</p>
        <p class="qb-card__meta">6-document source set · ${item.points || 7} points</p>
        <div class="qb-source-grid">
          ${sources
            .map(
              (s, i) => `
            <details class="qb-source" ${i === 0 ? "open" : ""}>
              <summary>Doc ${i + 1}: ${escapeHtml(s.title)}</summary>
              <p class="qb-source__type">${escapeHtml(s.source)}</p>
              <p class="qb-source__excerpt">${escapeHtml(s.excerpt)}</p>
            </details>`
            )
            .join("")}
        </div>
      </article>`;
  }

  function renderLeqCard(item) {
    return `
      <article class="qb-card qb-card--leq" data-period="${item.period}">
        <header class="qb-card__head">
          <span class="qb-card__badge">Period ${escapeHtml(item.period)}</span>
          <span class="qb-card__id">${escapeHtml(item.id)}</span>
        </header>
        <p class="qb-card__prompt">${escapeHtml(item.prompt)}</p>
        <p class="qb-card__meta">LEQ · ${item.points || 6} points</p>
      </article>`;
  }

  function renderSaqCard(item) {
    return `
      <article class="qb-card qb-card--saq" data-period="${item.period}">
        <header class="qb-card__head">
          <span class="qb-card__badge">Period ${escapeHtml(item.period)}</span>
          <span class="qb-card__id">${escapeHtml(item.id)}</span>
        </header>
        <p class="qb-card__prompt"><strong>${escapeHtml(item.prompt)}</strong></p>
        <p class="qb-card__question">${escapeHtml(item.question)}</p>
      </article>`;
  }

  function renderSupCard(item) {
    return `
      <article class="qb-card qb-card--sup" data-period="${item.period}" data-skill="${escapeHtml(item.skill)}">
        <header class="qb-card__head">
          <span class="qb-card__badge">P${escapeHtml(item.period)} · ${escapeHtml(item.skill)}</span>
          <span class="qb-card__id">${escapeHtml(item.id)}</span>
        </header>
        <p class="qb-card__question">${escapeHtml(item.question)}</p>
        <p class="qb-card__source"><strong>Source:</strong> ${escapeHtml(item.source)} <span class="qb-card__source-type">(${escapeHtml(item.sourceType)})</span></p>
        <p class="qb-card__hint">${escapeHtml(item.answerHint)}</p>
      </article>`;
  }

  function fillPanel(name) {
    const panel = root.querySelector(`[data-bank-panel="${name}"]`);
    if (!panel || panel.dataset.filled === "true") return;
    let html = "";
    if (name === "dbq") html = bank.dbqs.map(renderDbqCard).join("");
    if (name === "leq") html = bank.leqs.map(renderLeqCard).join("");
    if (name === "saq") html = bank.saqs.map(renderSaqCard).join("");
    if (name === "supplemental") html = bank.supplemental.map(renderSupCard).join("");
    panel.innerHTML = html || "<p class=\"qb-empty\">No items in this bank.</p>";
    panel.dataset.filled = "true";
  }

  function applySearch() {
    const q = (search?.value || "").trim().toLowerCase();
    root.querySelectorAll(".qb-card").forEach((card) => {
      const text = card.textContent.toLowerCase();
      card.hidden = q.length > 0 && !text.includes(q);
    });
  }

  tabs.forEach((tab) => {
    tab.addEventListener("click", () => {
      const target = tab.getAttribute("data-bank-tab");
      tabs.forEach((t) => {
        t.classList.toggle("qb-tab--active", t === tab);
        t.setAttribute("aria-selected", t === tab ? "true" : "false");
      });
      panels.forEach((p) => {
        const on = p.getAttribute("data-bank-panel") === target;
        p.hidden = !on;
        if (on) fillPanel(target);
      });
    });
  });

  if (search) search.addEventListener("input", applySearch);
  fillPanel("dbq");

  const stats = document.getElementById("question-bank-stats");
  if (stats) {
    stats.textContent = `${bank.dbqs.length} DBQs · ${bank.leqs.length} LEQs · ${bank.saqs.length} SAQs · ${bank.supplemental.length} supplemental`;
  }
});
