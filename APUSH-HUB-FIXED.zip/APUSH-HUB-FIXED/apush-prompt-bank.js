window.APUSH_PROMPT_BANK = {
  "dbqs": [
    {
      "id": "dbq-01",
      "period": 1,
      "label": "Colonial",
      "prompt": "Using the documents, analyze a major theme in Period 1 U.S. history (DBQ set 1).",
      "sources": [
        {
          "title": "Document 1 \u2014 Period 1",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 1 for DBQ 1.",
          "fullText": "Evidence excerpt 1 for DBQ 1."
        },
        {
          "title": "Document 2 \u2014 Period 1",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 2 for DBQ 1.",
          "fullText": "Evidence excerpt 2 for DBQ 1."
        },
        {
          "title": "Document 3 \u2014 Period 1",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 3 for DBQ 1.",
          "fullText": "Evidence excerpt 3 for DBQ 1."
        },
        {
          "title": "Document 4 \u2014 Period 1",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 4 for DBQ 1.",
          "fullText": "Evidence excerpt 4 for DBQ 1."
        },
        {
          "title": "Document 5 \u2014 Period 1",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 5 for DBQ 1.",
          "fullText": "Evidence excerpt 5 for DBQ 1."
        },
        {
          "title": "Document 6 \u2014 Period 1",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 6 for DBQ 1.",
          "fullText": "Evidence excerpt 6 for DBQ 1."
        }
      ],
      "points": 7
    },
    {
      "id": "dbq-02",
      "period": 2,
      "label": "Revolution",
      "prompt": "Using the documents, analyze a major theme in Period 2 U.S. history (DBQ set 2).",
      "sources": [
        {
          "title": "Document 1 \u2014 Period 2",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 1 for DBQ 2.",
          "fullText": "Evidence excerpt 1 for DBQ 2."
        },
        {
          "title": "Document 2 \u2014 Period 2",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 2 for DBQ 2.",
          "fullText": "Evidence excerpt 2 for DBQ 2."
        },
        {
          "title": "Document 3 \u2014 Period 2",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 3 for DBQ 2.",
          "fullText": "Evidence excerpt 3 for DBQ 2."
        },
        {
          "title": "Document 4 \u2014 Period 2",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 4 for DBQ 2.",
          "fullText": "Evidence excerpt 4 for DBQ 2."
        },
        {
          "title": "Document 5 \u2014 Period 2",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 5 for DBQ 2.",
          "fullText": "Evidence excerpt 5 for DBQ 2."
        },
        {
          "title": "Document 6 \u2014 Period 2",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 6 for DBQ 2.",
          "fullText": "Evidence excerpt 6 for DBQ 2."
        }
      ],
      "points": 7
    },
    {
      "id": "dbq-03",
      "period": 3,
      "label": "Early Republic",
      "prompt": "Using the documents, analyze a major theme in Period 3 U.S. history (DBQ set 3).",
      "sources": [
        {
          "title": "Document 1 \u2014 Period 3",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 1 for DBQ 3.",
          "fullText": "Evidence excerpt 1 for DBQ 3."
        },
        {
          "title": "Document 2 \u2014 Period 3",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 2 for DBQ 3.",
          "fullText": "Evidence excerpt 2 for DBQ 3."
        },
        {
          "title": "Document 3 \u2014 Period 3",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 3 for DBQ 3.",
          "fullText": "Evidence excerpt 3 for DBQ 3."
        },
        {
          "title": "Document 4 \u2014 Period 3",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 4 for DBQ 3.",
          "fullText": "Evidence excerpt 4 for DBQ 3."
        },
        {
          "title": "Document 5 \u2014 Period 3",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 5 for DBQ 3.",
          "fullText": "Evidence excerpt 5 for DBQ 3."
        },
        {
          "title": "Document 6 \u2014 Period 3",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 6 for DBQ 3.",
          "fullText": "Evidence excerpt 6 for DBQ 3."
        }
      ],
      "points": 7
    },
    {
      "id": "dbq-04",
      "period": 4,
      "label": "Sectionalism",
      "prompt": "Using the documents, analyze a major theme in Period 4 U.S. history (DBQ set 4).",
      "sources": [
        {
          "title": "Document 1 \u2014 Period 4",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 1 for DBQ 4.",
          "fullText": "Evidence excerpt 1 for DBQ 4."
        },
        {
          "title": "Document 2 \u2014 Period 4",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 2 for DBQ 4.",
          "fullText": "Evidence excerpt 2 for DBQ 4."
        },
        {
          "title": "Document 3 \u2014 Period 4",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 3 for DBQ 4.",
          "fullText": "Evidence excerpt 3 for DBQ 4."
        },
        {
          "title": "Document 4 \u2014 Period 4",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 4 for DBQ 4.",
          "fullText": "Evidence excerpt 4 for DBQ 4."
        },
        {
          "title": "Document 5 \u2014 Period 4",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 5 for DBQ 4.",
          "fullText": "Evidence excerpt 5 for DBQ 4."
        },
        {
          "title": "Document 6 \u2014 Period 4",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 6 for DBQ 4.",
          "fullText": "Evidence excerpt 6 for DBQ 4."
        }
      ],
      "points": 7
    },
    {
      "id": "dbq-05",
      "period": 5,
      "label": "Civil War",
      "prompt": "Using the documents, analyze a major theme in Period 5 U.S. history (DBQ set 5).",
      "sources": [
        {
          "title": "Document 1 \u2014 Period 5",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 1 for DBQ 5.",
          "fullText": "Evidence excerpt 1 for DBQ 5."
        },
        {
          "title": "Document 2 \u2014 Period 5",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 2 for DBQ 5.",
          "fullText": "Evidence excerpt 2 for DBQ 5."
        },
        {
          "title": "Document 3 \u2014 Period 5",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 3 for DBQ 5.",
          "fullText": "Evidence excerpt 3 for DBQ 5."
        },
        {
          "title": "Document 4 \u2014 Period 5",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 4 for DBQ 5.",
          "fullText": "Evidence excerpt 4 for DBQ 5."
        },
        {
          "title": "Document 5 \u2014 Period 5",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 5 for DBQ 5.",
          "fullText": "Evidence excerpt 5 for DBQ 5."
        },
        {
          "title": "Document 6 \u2014 Period 5",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 6 for DBQ 5.",
          "fullText": "Evidence excerpt 6 for DBQ 5."
        }
      ],
      "points": 7
    },
    {
      "id": "dbq-06",
      "period": 6,
      "label": "Industrial",
      "prompt": "Using the documents, analyze a major theme in Period 6 U.S. history (DBQ set 6).",
      "sources": [
        {
          "title": "Document 1 \u2014 Period 6",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 1 for DBQ 6.",
          "fullText": "Evidence excerpt 1 for DBQ 6."
        },
        {
          "title": "Document 2 \u2014 Period 6",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 2 for DBQ 6.",
          "fullText": "Evidence excerpt 2 for DBQ 6."
        },
        {
          "title": "Document 3 \u2014 Period 6",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 3 for DBQ 6.",
          "fullText": "Evidence excerpt 3 for DBQ 6."
        },
        {
          "title": "Document 4 \u2014 Period 6",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 4 for DBQ 6.",
          "fullText": "Evidence excerpt 4 for DBQ 6."
        },
        {
          "title": "Document 5 \u2014 Period 6",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 5 for DBQ 6.",
          "fullText": "Evidence excerpt 5 for DBQ 6."
        },
        {
          "title": "Document 6 \u2014 Period 6",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 6 for DBQ 6.",
          "fullText": "Evidence excerpt 6 for DBQ 6."
        }
      ],
      "points": 7
    },
    {
      "id": "dbq-07",
      "period": 7,
      "label": "Modern",
      "prompt": "Using the documents, analyze a major theme in Period 7 U.S. history (DBQ set 7).",
      "sources": [
        {
          "title": "Document 1 \u2014 Period 7",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 1 for DBQ 7.",
          "fullText": "Evidence excerpt 1 for DBQ 7."
        },
        {
          "title": "Document 2 \u2014 Period 7",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 2 for DBQ 7.",
          "fullText": "Evidence excerpt 2 for DBQ 7."
        },
        {
          "title": "Document 3 \u2014 Period 7",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 3 for DBQ 7.",
          "fullText": "Evidence excerpt 3 for DBQ 7."
        },
        {
          "title": "Document 4 \u2014 Period 7",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 4 for DBQ 7.",
          "fullText": "Evidence excerpt 4 for DBQ 7."
        },
        {
          "title": "Document 5 \u2014 Period 7",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 5 for DBQ 7.",
          "fullText": "Evidence excerpt 5 for DBQ 7."
        },
        {
          "title": "Document 6 \u2014 Period 7",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 6 for DBQ 7.",
          "fullText": "Evidence excerpt 6 for DBQ 7."
        }
      ],
      "points": 7
    },
    {
      "id": "dbq-08",
      "period": 8,
      "label": "Contemporary",
      "prompt": "Using the documents, analyze a major theme in Period 8 U.S. history (DBQ set 8).",
      "sources": [
        {
          "title": "Document 1 \u2014 Period 8",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 1 for DBQ 8.",
          "fullText": "Evidence excerpt 1 for DBQ 8."
        },
        {
          "title": "Document 2 \u2014 Period 8",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 2 for DBQ 8.",
          "fullText": "Evidence excerpt 2 for DBQ 8."
        },
        {
          "title": "Document 3 \u2014 Period 8",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 3 for DBQ 8.",
          "fullText": "Evidence excerpt 3 for DBQ 8."
        },
        {
          "title": "Document 4 \u2014 Period 8",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 4 for DBQ 8.",
          "fullText": "Evidence excerpt 4 for DBQ 8."
        },
        {
          "title": "Document 5 \u2014 Period 8",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 5 for DBQ 8.",
          "fullText": "Evidence excerpt 5 for DBQ 8."
        },
        {
          "title": "Document 6 \u2014 Period 8",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 6 for DBQ 8.",
          "fullText": "Evidence excerpt 6 for DBQ 8."
        }
      ],
      "points": 7
    },
    {
      "id": "dbq-09",
      "period": 1,
      "label": "Colonial",
      "prompt": "Using the documents, analyze a major theme in Period 1 U.S. history (DBQ set 9).",
      "sources": [
        {
          "title": "Document 1 \u2014 Period 1",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 1 for DBQ 9.",
          "fullText": "Evidence excerpt 1 for DBQ 9."
        },
        {
          "title": "Document 2 \u2014 Period 1",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 2 for DBQ 9.",
          "fullText": "Evidence excerpt 2 for DBQ 9."
        },
        {
          "title": "Document 3 \u2014 Period 1",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 3 for DBQ 9.",
          "fullText": "Evidence excerpt 3 for DBQ 9."
        },
        {
          "title": "Document 4 \u2014 Period 1",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 4 for DBQ 9.",
          "fullText": "Evidence excerpt 4 for DBQ 9."
        },
        {
          "title": "Document 5 \u2014 Period 1",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 5 for DBQ 9.",
          "fullText": "Evidence excerpt 5 for DBQ 9."
        },
        {
          "title": "Document 6 \u2014 Period 1",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 6 for DBQ 9.",
          "fullText": "Evidence excerpt 6 for DBQ 9."
        }
      ],
      "points": 7
    },
    {
      "id": "dbq-10",
      "period": 2,
      "label": "Revolution",
      "prompt": "Using the documents, analyze a major theme in Period 2 U.S. history (DBQ set 10).",
      "sources": [
        {
          "title": "Document 1 \u2014 Period 2",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 1 for DBQ 10.",
          "fullText": "Evidence excerpt 1 for DBQ 10."
        },
        {
          "title": "Document 2 \u2014 Period 2",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 2 for DBQ 10.",
          "fullText": "Evidence excerpt 2 for DBQ 10."
        },
        {
          "title": "Document 3 \u2014 Period 2",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 3 for DBQ 10.",
          "fullText": "Evidence excerpt 3 for DBQ 10."
        },
        {
          "title": "Document 4 \u2014 Period 2",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 4 for DBQ 10.",
          "fullText": "Evidence excerpt 4 for DBQ 10."
        },
        {
          "title": "Document 5 \u2014 Period 2",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 5 for DBQ 10.",
          "fullText": "Evidence excerpt 5 for DBQ 10."
        },
        {
          "title": "Document 6 \u2014 Period 2",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 6 for DBQ 10.",
          "fullText": "Evidence excerpt 6 for DBQ 10."
        }
      ],
      "points": 7
    },
    {
      "id": "dbq-11",
      "period": 3,
      "label": "Early Republic",
      "prompt": "Using the documents, analyze a major theme in Period 3 U.S. history (DBQ set 11).",
      "sources": [
        {
          "title": "Document 1 \u2014 Period 3",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 1 for DBQ 11.",
          "fullText": "Evidence excerpt 1 for DBQ 11."
        },
        {
          "title": "Document 2 \u2014 Period 3",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 2 for DBQ 11.",
          "fullText": "Evidence excerpt 2 for DBQ 11."
        },
        {
          "title": "Document 3 \u2014 Period 3",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 3 for DBQ 11.",
          "fullText": "Evidence excerpt 3 for DBQ 11."
        },
        {
          "title": "Document 4 \u2014 Period 3",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 4 for DBQ 11.",
          "fullText": "Evidence excerpt 4 for DBQ 11."
        },
        {
          "title": "Document 5 \u2014 Period 3",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 5 for DBQ 11.",
          "fullText": "Evidence excerpt 5 for DBQ 11."
        },
        {
          "title": "Document 6 \u2014 Period 3",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 6 for DBQ 11.",
          "fullText": "Evidence excerpt 6 for DBQ 11."
        }
      ],
      "points": 7
    },
    {
      "id": "dbq-12",
      "period": 4,
      "label": "Sectionalism",
      "prompt": "Using the documents, analyze a major theme in Period 4 U.S. history (DBQ set 12).",
      "sources": [
        {
          "title": "Document 1 \u2014 Period 4",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 1 for DBQ 12.",
          "fullText": "Evidence excerpt 1 for DBQ 12."
        },
        {
          "title": "Document 2 \u2014 Period 4",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 2 for DBQ 12.",
          "fullText": "Evidence excerpt 2 for DBQ 12."
        },
        {
          "title": "Document 3 \u2014 Period 4",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 3 for DBQ 12.",
          "fullText": "Evidence excerpt 3 for DBQ 12."
        },
        {
          "title": "Document 4 \u2014 Period 4",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 4 for DBQ 12.",
          "fullText": "Evidence excerpt 4 for DBQ 12."
        },
        {
          "title": "Document 5 \u2014 Period 4",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 5 for DBQ 12.",
          "fullText": "Evidence excerpt 5 for DBQ 12."
        },
        {
          "title": "Document 6 \u2014 Period 4",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 6 for DBQ 12.",
          "fullText": "Evidence excerpt 6 for DBQ 12."
        }
      ],
      "points": 7
    },
    {
      "id": "dbq-13",
      "period": 5,
      "label": "Civil War",
      "prompt": "Using the documents, analyze a major theme in Period 5 U.S. history (DBQ set 13).",
      "sources": [
        {
          "title": "Document 1 \u2014 Period 5",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 1 for DBQ 13.",
          "fullText": "Evidence excerpt 1 for DBQ 13."
        },
        {
          "title": "Document 2 \u2014 Period 5",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 2 for DBQ 13.",
          "fullText": "Evidence excerpt 2 for DBQ 13."
        },
        {
          "title": "Document 3 \u2014 Period 5",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 3 for DBQ 13.",
          "fullText": "Evidence excerpt 3 for DBQ 13."
        },
        {
          "title": "Document 4 \u2014 Period 5",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 4 for DBQ 13.",
          "fullText": "Evidence excerpt 4 for DBQ 13."
        },
        {
          "title": "Document 5 \u2014 Period 5",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 5 for DBQ 13.",
          "fullText": "Evidence excerpt 5 for DBQ 13."
        },
        {
          "title": "Document 6 \u2014 Period 5",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 6 for DBQ 13.",
          "fullText": "Evidence excerpt 6 for DBQ 13."
        }
      ],
      "points": 7
    },
    {
      "id": "dbq-14",
      "period": 6,
      "label": "Industrial",
      "prompt": "Using the documents, analyze a major theme in Period 6 U.S. history (DBQ set 14).",
      "sources": [
        {
          "title": "Document 1 \u2014 Period 6",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 1 for DBQ 14.",
          "fullText": "Evidence excerpt 1 for DBQ 14."
        },
        {
          "title": "Document 2 \u2014 Period 6",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 2 for DBQ 14.",
          "fullText": "Evidence excerpt 2 for DBQ 14."
        },
        {
          "title": "Document 3 \u2014 Period 6",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 3 for DBQ 14.",
          "fullText": "Evidence excerpt 3 for DBQ 14."
        },
        {
          "title": "Document 4 \u2014 Period 6",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 4 for DBQ 14.",
          "fullText": "Evidence excerpt 4 for DBQ 14."
        },
        {
          "title": "Document 5 \u2014 Period 6",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 5 for DBQ 14.",
          "fullText": "Evidence excerpt 5 for DBQ 14."
        },
        {
          "title": "Document 6 \u2014 Period 6",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 6 for DBQ 14.",
          "fullText": "Evidence excerpt 6 for DBQ 14."
        }
      ],
      "points": 7
    },
    {
      "id": "dbq-15",
      "period": 7,
      "label": "Modern",
      "prompt": "Using the documents, analyze a major theme in Period 7 U.S. history (DBQ set 15).",
      "sources": [
        {
          "title": "Document 1 \u2014 Period 7",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 1 for DBQ 15.",
          "fullText": "Evidence excerpt 1 for DBQ 15."
        },
        {
          "title": "Document 2 \u2014 Period 7",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 2 for DBQ 15.",
          "fullText": "Evidence excerpt 2 for DBQ 15."
        },
        {
          "title": "Document 3 \u2014 Period 7",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 3 for DBQ 15.",
          "fullText": "Evidence excerpt 3 for DBQ 15."
        },
        {
          "title": "Document 4 \u2014 Period 7",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 4 for DBQ 15.",
          "fullText": "Evidence excerpt 4 for DBQ 15."
        },
        {
          "title": "Document 5 \u2014 Period 7",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 5 for DBQ 15.",
          "fullText": "Evidence excerpt 5 for DBQ 15."
        },
        {
          "title": "Document 6 \u2014 Period 7",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 6 for DBQ 15.",
          "fullText": "Evidence excerpt 6 for DBQ 15."
        }
      ],
      "points": 7
    },
    {
      "id": "dbq-16",
      "period": 8,
      "label": "Contemporary",
      "prompt": "Using the documents, analyze a major theme in Period 8 U.S. history (DBQ set 16).",
      "sources": [
        {
          "title": "Document 1 \u2014 Period 8",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 1 for DBQ 16.",
          "fullText": "Evidence excerpt 1 for DBQ 16."
        },
        {
          "title": "Document 2 \u2014 Period 8",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 2 for DBQ 16.",
          "fullText": "Evidence excerpt 2 for DBQ 16."
        },
        {
          "title": "Document 3 \u2014 Period 8",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 3 for DBQ 16.",
          "fullText": "Evidence excerpt 3 for DBQ 16."
        },
        {
          "title": "Document 4 \u2014 Period 8",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 4 for DBQ 16.",
          "fullText": "Evidence excerpt 4 for DBQ 16."
        },
        {
          "title": "Document 5 \u2014 Period 8",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 5 for DBQ 16.",
          "fullText": "Evidence excerpt 5 for DBQ 16."
        },
        {
          "title": "Document 6 \u2014 Period 8",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 6 for DBQ 16.",
          "fullText": "Evidence excerpt 6 for DBQ 16."
        }
      ],
      "points": 7
    },
    {
      "id": "dbq-17",
      "period": 1,
      "label": "Colonial",
      "prompt": "Using the documents, analyze a major theme in Period 1 U.S. history (DBQ set 17).",
      "sources": [
        {
          "title": "Document 1 \u2014 Period 1",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 1 for DBQ 17.",
          "fullText": "Evidence excerpt 1 for DBQ 17."
        },
        {
          "title": "Document 2 \u2014 Period 1",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 2 for DBQ 17.",
          "fullText": "Evidence excerpt 2 for DBQ 17."
        },
        {
          "title": "Document 3 \u2014 Period 1",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 3 for DBQ 17.",
          "fullText": "Evidence excerpt 3 for DBQ 17."
        },
        {
          "title": "Document 4 \u2014 Period 1",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 4 for DBQ 17.",
          "fullText": "Evidence excerpt 4 for DBQ 17."
        },
        {
          "title": "Document 5 \u2014 Period 1",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 5 for DBQ 17.",
          "fullText": "Evidence excerpt 5 for DBQ 17."
        },
        {
          "title": "Document 6 \u2014 Period 1",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 6 for DBQ 17.",
          "fullText": "Evidence excerpt 6 for DBQ 17."
        }
      ],
      "points": 7
    },
    {
      "id": "dbq-18",
      "period": 2,
      "label": "Revolution",
      "prompt": "Using the documents, analyze a major theme in Period 2 U.S. history (DBQ set 18).",
      "sources": [
        {
          "title": "Document 1 \u2014 Period 2",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 1 for DBQ 18.",
          "fullText": "Evidence excerpt 1 for DBQ 18."
        },
        {
          "title": "Document 2 \u2014 Period 2",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 2 for DBQ 18.",
          "fullText": "Evidence excerpt 2 for DBQ 18."
        },
        {
          "title": "Document 3 \u2014 Period 2",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 3 for DBQ 18.",
          "fullText": "Evidence excerpt 3 for DBQ 18."
        },
        {
          "title": "Document 4 \u2014 Period 2",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 4 for DBQ 18.",
          "fullText": "Evidence excerpt 4 for DBQ 18."
        },
        {
          "title": "Document 5 \u2014 Period 2",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 5 for DBQ 18.",
          "fullText": "Evidence excerpt 5 for DBQ 18."
        },
        {
          "title": "Document 6 \u2014 Period 2",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 6 for DBQ 18.",
          "fullText": "Evidence excerpt 6 for DBQ 18."
        }
      ],
      "points": 7
    },
    {
      "id": "dbq-19",
      "period": 3,
      "label": "Early Republic",
      "prompt": "Using the documents, analyze a major theme in Period 3 U.S. history (DBQ set 19).",
      "sources": [
        {
          "title": "Document 1 \u2014 Period 3",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 1 for DBQ 19.",
          "fullText": "Evidence excerpt 1 for DBQ 19."
        },
        {
          "title": "Document 2 \u2014 Period 3",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 2 for DBQ 19.",
          "fullText": "Evidence excerpt 2 for DBQ 19."
        },
        {
          "title": "Document 3 \u2014 Period 3",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 3 for DBQ 19.",
          "fullText": "Evidence excerpt 3 for DBQ 19."
        },
        {
          "title": "Document 4 \u2014 Period 3",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 4 for DBQ 19.",
          "fullText": "Evidence excerpt 4 for DBQ 19."
        },
        {
          "title": "Document 5 \u2014 Period 3",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 5 for DBQ 19.",
          "fullText": "Evidence excerpt 5 for DBQ 19."
        },
        {
          "title": "Document 6 \u2014 Period 3",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 6 for DBQ 19.",
          "fullText": "Evidence excerpt 6 for DBQ 19."
        }
      ],
      "points": 7
    },
    {
      "id": "dbq-20",
      "period": 4,
      "label": "Sectionalism",
      "prompt": "Using the documents, analyze a major theme in Period 4 U.S. history (DBQ set 20).",
      "sources": [
        {
          "title": "Document 1 \u2014 Period 4",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 1 for DBQ 20.",
          "fullText": "Evidence excerpt 1 for DBQ 20."
        },
        {
          "title": "Document 2 \u2014 Period 4",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 2 for DBQ 20.",
          "fullText": "Evidence excerpt 2 for DBQ 20."
        },
        {
          "title": "Document 3 \u2014 Period 4",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 3 for DBQ 20.",
          "fullText": "Evidence excerpt 3 for DBQ 20."
        },
        {
          "title": "Document 4 \u2014 Period 4",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 4 for DBQ 20.",
          "fullText": "Evidence excerpt 4 for DBQ 20."
        },
        {
          "title": "Document 5 \u2014 Period 4",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 5 for DBQ 20.",
          "fullText": "Evidence excerpt 5 for DBQ 20."
        },
        {
          "title": "Document 6 \u2014 Period 4",
          "source": "Primary source",
          "excerpt": "Evidence excerpt 6 for DBQ 20.",
          "fullText": "Evidence excerpt 6 for DBQ 20."
        }
      ],
      "points": 7
    }
  ],
  "leqs": [
    {
      "id": "leq-01",
      "period": 1,
      "prompt": "Evaluate the extent to which a key development shaped U.S. history in Period 1 (LEQ 1).",
      "points": 6
    },
    {
      "id": "leq-02",
      "period": 2,
      "prompt": "Evaluate the extent to which a key development shaped U.S. history in Period 2 (LEQ 2).",
      "points": 6
    },
    {
      "id": "leq-03",
      "period": 3,
      "prompt": "Evaluate the extent to which a key development shaped U.S. history in Period 3 (LEQ 3).",
      "points": 6
    },
    {
      "id": "leq-04",
      "period": 4,
      "prompt": "Evaluate the extent to which a key development shaped U.S. history in Period 4 (LEQ 4).",
      "points": 6
    },
    {
      "id": "leq-05",
      "period": 5,
      "prompt": "Evaluate the extent to which a key development shaped U.S. history in Period 5 (LEQ 5).",
      "points": 6
    },
    {
      "id": "leq-06",
      "period": 6,
      "prompt": "Evaluate the extent to which a key development shaped U.S. history in Period 6 (LEQ 6).",
      "points": 6
    },
    {
      "id": "leq-07",
      "period": 7,
      "prompt": "Evaluate the extent to which a key development shaped U.S. history in Period 7 (LEQ 7).",
      "points": 6
    },
    {
      "id": "leq-08",
      "period": 8,
      "prompt": "Evaluate the extent to which a key development shaped U.S. history in Period 8 (LEQ 8).",
      "points": 6
    },
    {
      "id": "leq-09",
      "period": 1,
      "prompt": "Evaluate the extent to which a key development shaped U.S. history in Period 1 (LEQ 9).",
      "points": 6
    },
    {
      "id": "leq-10",
      "period": 2,
      "prompt": "Evaluate the extent to which a key development shaped U.S. history in Period 2 (LEQ 10).",
      "points": 6
    },
    {
      "id": "leq-11",
      "period": 3,
      "prompt": "Evaluate the extent to which a key development shaped U.S. history in Period 3 (LEQ 11).",
      "points": 6
    },
    {
      "id": "leq-12",
      "period": 4,
      "prompt": "Evaluate the extent to which a key development shaped U.S. history in Period 4 (LEQ 12).",
      "points": 6
    },
    {
      "id": "leq-13",
      "period": 5,
      "prompt": "Evaluate the extent to which a key development shaped U.S. history in Period 5 (LEQ 13).",
      "points": 6
    },
    {
      "id": "leq-14",
      "period": 6,
      "prompt": "Evaluate the extent to which a key development shaped U.S. history in Period 6 (LEQ 14).",
      "points": 6
    },
    {
      "id": "leq-15",
      "period": 7,
      "prompt": "Evaluate the extent to which a key development shaped U.S. history in Period 7 (LEQ 15).",
      "points": 6
    },
    {
      "id": "leq-16",
      "period": 8,
      "prompt": "Evaluate the extent to which a key development shaped U.S. history in Period 8 (LEQ 16).",
      "points": 6
    },
    {
      "id": "leq-17",
      "period": 1,
      "prompt": "Evaluate the extent to which a key development shaped U.S. history in Period 1 (LEQ 17).",
      "points": 6
    },
    {
      "id": "leq-18",
      "period": 2,
      "prompt": "Evaluate the extent to which a key development shaped U.S. history in Period 2 (LEQ 18).",
      "points": 6
    },
    {
      "id": "leq-19",
      "period": 3,
      "prompt": "Evaluate the extent to which a key development shaped U.S. history in Period 3 (LEQ 19).",
      "points": 6
    },
    {
      "id": "leq-20",
      "period": 4,
      "prompt": "Evaluate the extent to which a key development shaped U.S. history in Period 4 (LEQ 20).",
      "points": 6
    }
  ],
  "saqs": [
    {
      "id": "saq-001",
      "period": 1,
      "prompt": "(a) Briefly describe ONE event from Period 1.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-002",
      "period": 2,
      "prompt": "(a) Briefly describe ONE event from Period 2.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-003",
      "period": 3,
      "prompt": "(a) Briefly describe ONE event from Period 3.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-004",
      "period": 4,
      "prompt": "(a) Briefly describe ONE event from Period 4.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-005",
      "period": 5,
      "prompt": "(a) Briefly describe ONE event from Period 5.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-006",
      "period": 6,
      "prompt": "(a) Briefly describe ONE event from Period 6.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-007",
      "period": 7,
      "prompt": "(a) Briefly describe ONE event from Period 7.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-008",
      "period": 8,
      "prompt": "(a) Briefly describe ONE event from Period 8.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-009",
      "period": 1,
      "prompt": "(a) Briefly describe ONE event from Period 1.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-010",
      "period": 2,
      "prompt": "(a) Briefly describe ONE event from Period 2.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-011",
      "period": 3,
      "prompt": "(a) Briefly describe ONE event from Period 3.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-012",
      "period": 4,
      "prompt": "(a) Briefly describe ONE event from Period 4.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-013",
      "period": 5,
      "prompt": "(a) Briefly describe ONE event from Period 5.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-014",
      "period": 6,
      "prompt": "(a) Briefly describe ONE event from Period 6.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-015",
      "period": 7,
      "prompt": "(a) Briefly describe ONE event from Period 7.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-016",
      "period": 8,
      "prompt": "(a) Briefly describe ONE event from Period 8.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-017",
      "period": 1,
      "prompt": "(a) Briefly describe ONE event from Period 1.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-018",
      "period": 2,
      "prompt": "(a) Briefly describe ONE event from Period 2.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-019",
      "period": 3,
      "prompt": "(a) Briefly describe ONE event from Period 3.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-020",
      "period": 4,
      "prompt": "(a) Briefly describe ONE event from Period 4.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-021",
      "period": 5,
      "prompt": "(a) Briefly describe ONE event from Period 5.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-022",
      "period": 6,
      "prompt": "(a) Briefly describe ONE event from Period 6.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-023",
      "period": 7,
      "prompt": "(a) Briefly describe ONE event from Period 7.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-024",
      "period": 8,
      "prompt": "(a) Briefly describe ONE event from Period 8.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-025",
      "period": 1,
      "prompt": "(a) Briefly describe ONE event from Period 1.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-026",
      "period": 2,
      "prompt": "(a) Briefly describe ONE event from Period 2.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-027",
      "period": 3,
      "prompt": "(a) Briefly describe ONE event from Period 3.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-028",
      "period": 4,
      "prompt": "(a) Briefly describe ONE event from Period 4.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-029",
      "period": 5,
      "prompt": "(a) Briefly describe ONE event from Period 5.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-030",
      "period": 6,
      "prompt": "(a) Briefly describe ONE event from Period 6.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-031",
      "period": 7,
      "prompt": "(a) Briefly describe ONE event from Period 7.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-032",
      "period": 8,
      "prompt": "(a) Briefly describe ONE event from Period 8.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-033",
      "period": 1,
      "prompt": "(a) Briefly describe ONE event from Period 1.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-034",
      "period": 2,
      "prompt": "(a) Briefly describe ONE event from Period 2.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-035",
      "period": 3,
      "prompt": "(a) Briefly describe ONE event from Period 3.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-036",
      "period": 4,
      "prompt": "(a) Briefly describe ONE event from Period 4.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-037",
      "period": 5,
      "prompt": "(a) Briefly describe ONE event from Period 5.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-038",
      "period": 6,
      "prompt": "(a) Briefly describe ONE event from Period 6.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-039",
      "period": 7,
      "prompt": "(a) Briefly describe ONE event from Period 7.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-040",
      "period": 8,
      "prompt": "(a) Briefly describe ONE event from Period 8.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-041",
      "period": 1,
      "prompt": "(a) Briefly describe ONE event from Period 1.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-042",
      "period": 2,
      "prompt": "(a) Briefly describe ONE event from Period 2.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-043",
      "period": 3,
      "prompt": "(a) Briefly describe ONE event from Period 3.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-044",
      "period": 4,
      "prompt": "(a) Briefly describe ONE event from Period 4.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-045",
      "period": 5,
      "prompt": "(a) Briefly describe ONE event from Period 5.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-046",
      "period": 6,
      "prompt": "(a) Briefly describe ONE event from Period 6.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-047",
      "period": 7,
      "prompt": "(a) Briefly describe ONE event from Period 7.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-048",
      "period": 8,
      "prompt": "(a) Briefly describe ONE event from Period 8.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-049",
      "period": 1,
      "prompt": "(a) Briefly describe ONE event from Period 1.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-050",
      "period": 2,
      "prompt": "(a) Briefly describe ONE event from Period 2.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-051",
      "period": 3,
      "prompt": "(a) Briefly describe ONE event from Period 3.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-052",
      "period": 4,
      "prompt": "(a) Briefly describe ONE event from Period 4.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-053",
      "period": 5,
      "prompt": "(a) Briefly describe ONE event from Period 5.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-054",
      "period": 6,
      "prompt": "(a) Briefly describe ONE event from Period 6.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-055",
      "period": 7,
      "prompt": "(a) Briefly describe ONE event from Period 7.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-056",
      "period": 8,
      "prompt": "(a) Briefly describe ONE event from Period 8.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-057",
      "period": 1,
      "prompt": "(a) Briefly describe ONE event from Period 1.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-058",
      "period": 2,
      "prompt": "(a) Briefly describe ONE event from Period 2.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-059",
      "period": 3,
      "prompt": "(a) Briefly describe ONE event from Period 3.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-060",
      "period": 4,
      "prompt": "(a) Briefly describe ONE event from Period 4.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-061",
      "period": 5,
      "prompt": "(a) Briefly describe ONE event from Period 5.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-062",
      "period": 6,
      "prompt": "(a) Briefly describe ONE event from Period 6.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-063",
      "period": 7,
      "prompt": "(a) Briefly describe ONE event from Period 7.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-064",
      "period": 8,
      "prompt": "(a) Briefly describe ONE event from Period 8.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-065",
      "period": 1,
      "prompt": "(a) Briefly describe ONE event from Period 1.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-066",
      "period": 2,
      "prompt": "(a) Briefly describe ONE event from Period 2.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-067",
      "period": 3,
      "prompt": "(a) Briefly describe ONE event from Period 3.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-068",
      "period": 4,
      "prompt": "(a) Briefly describe ONE event from Period 4.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-069",
      "period": 5,
      "prompt": "(a) Briefly describe ONE event from Period 5.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-070",
      "period": 6,
      "prompt": "(a) Briefly describe ONE event from Period 6.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-071",
      "period": 7,
      "prompt": "(a) Briefly describe ONE event from Period 7.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-072",
      "period": 8,
      "prompt": "(a) Briefly describe ONE event from Period 8.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-073",
      "period": 1,
      "prompt": "(a) Briefly describe ONE event from Period 1.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-074",
      "period": 2,
      "prompt": "(a) Briefly describe ONE event from Period 2.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-075",
      "period": 3,
      "prompt": "(a) Briefly describe ONE event from Period 3.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-076",
      "period": 4,
      "prompt": "(a) Briefly describe ONE event from Period 4.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-077",
      "period": 5,
      "prompt": "(a) Briefly describe ONE event from Period 5.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-078",
      "period": 6,
      "prompt": "(a) Briefly describe ONE event from Period 6.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-079",
      "period": 7,
      "prompt": "(a) Briefly describe ONE event from Period 7.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-080",
      "period": 8,
      "prompt": "(a) Briefly describe ONE event from Period 8.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-081",
      "period": 1,
      "prompt": "(a) Briefly describe ONE event from Period 1.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-082",
      "period": 2,
      "prompt": "(a) Briefly describe ONE event from Period 2.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-083",
      "period": 3,
      "prompt": "(a) Briefly describe ONE event from Period 3.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-084",
      "period": 4,
      "prompt": "(a) Briefly describe ONE event from Period 4.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-085",
      "period": 5,
      "prompt": "(a) Briefly describe ONE event from Period 5.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-086",
      "period": 6,
      "prompt": "(a) Briefly describe ONE event from Period 6.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-087",
      "period": 7,
      "prompt": "(a) Briefly describe ONE event from Period 7.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-088",
      "period": 8,
      "prompt": "(a) Briefly describe ONE event from Period 8.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-089",
      "period": 1,
      "prompt": "(a) Briefly describe ONE event from Period 1.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-090",
      "period": 2,
      "prompt": "(a) Briefly describe ONE event from Period 2.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-091",
      "period": 3,
      "prompt": "(a) Briefly describe ONE event from Period 3.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-092",
      "period": 4,
      "prompt": "(a) Briefly describe ONE event from Period 4.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-093",
      "period": 5,
      "prompt": "(a) Briefly describe ONE event from Period 5.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-094",
      "period": 6,
      "prompt": "(a) Briefly describe ONE event from Period 6.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-095",
      "period": 7,
      "prompt": "(a) Briefly describe ONE event from Period 7.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-096",
      "period": 8,
      "prompt": "(a) Briefly describe ONE event from Period 8.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-097",
      "period": 1,
      "prompt": "(a) Briefly describe ONE event from Period 1.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-098",
      "period": 2,
      "prompt": "(a) Briefly describe ONE event from Period 2.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-099",
      "period": 3,
      "prompt": "(a) Briefly describe ONE event from Period 3.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    },
    {
      "id": "saq-100",
      "period": 4,
      "prompt": "(a) Briefly describe ONE event from Period 4.",
      "question": "(b) Explain ONE cause OR effect related to your description in part (a)."
    }
  ],
  "supplemental": [
    {
      "id": "sup-001",
      "period": 1,
      "skill": "leq",
      "question": "Supplemental LEQ drill #1 for Period 1.",
      "source": "Archive reference 1",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-002",
      "period": 2,
      "skill": "saq",
      "question": "Supplemental SAQ drill #2 for Period 2.",
      "source": "Archive reference 2",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-003",
      "period": 3,
      "skill": "mcq",
      "question": "Supplemental MCQ drill #3 for Period 3.",
      "source": "Archive reference 3",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-004",
      "period": 4,
      "skill": "dbq",
      "question": "Supplemental DBQ drill #4 for Period 4.",
      "source": "Archive reference 4",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-005",
      "period": 5,
      "skill": "leq",
      "question": "Supplemental LEQ drill #5 for Period 5.",
      "source": "Archive reference 5",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-006",
      "period": 6,
      "skill": "saq",
      "question": "Supplemental SAQ drill #6 for Period 6.",
      "source": "Archive reference 6",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-007",
      "period": 7,
      "skill": "mcq",
      "question": "Supplemental MCQ drill #7 for Period 7.",
      "source": "Archive reference 7",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-008",
      "period": 8,
      "skill": "dbq",
      "question": "Supplemental DBQ drill #8 for Period 8.",
      "source": "Archive reference 8",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-009",
      "period": 1,
      "skill": "leq",
      "question": "Supplemental LEQ drill #9 for Period 1.",
      "source": "Archive reference 9",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-010",
      "period": 2,
      "skill": "saq",
      "question": "Supplemental SAQ drill #10 for Period 2.",
      "source": "Archive reference 10",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-011",
      "period": 3,
      "skill": "mcq",
      "question": "Supplemental MCQ drill #11 for Period 3.",
      "source": "Archive reference 11",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-012",
      "period": 4,
      "skill": "dbq",
      "question": "Supplemental DBQ drill #12 for Period 4.",
      "source": "Archive reference 12",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-013",
      "period": 5,
      "skill": "leq",
      "question": "Supplemental LEQ drill #13 for Period 5.",
      "source": "Archive reference 13",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-014",
      "period": 6,
      "skill": "saq",
      "question": "Supplemental SAQ drill #14 for Period 6.",
      "source": "Archive reference 14",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-015",
      "period": 7,
      "skill": "mcq",
      "question": "Supplemental MCQ drill #15 for Period 7.",
      "source": "Archive reference 15",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-016",
      "period": 8,
      "skill": "dbq",
      "question": "Supplemental DBQ drill #16 for Period 8.",
      "source": "Archive reference 16",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-017",
      "period": 1,
      "skill": "leq",
      "question": "Supplemental LEQ drill #17 for Period 1.",
      "source": "Archive reference 17",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-018",
      "period": 2,
      "skill": "saq",
      "question": "Supplemental SAQ drill #18 for Period 2.",
      "source": "Archive reference 18",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-019",
      "period": 3,
      "skill": "mcq",
      "question": "Supplemental MCQ drill #19 for Period 3.",
      "source": "Archive reference 19",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-020",
      "period": 4,
      "skill": "dbq",
      "question": "Supplemental DBQ drill #20 for Period 4.",
      "source": "Archive reference 20",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-021",
      "period": 5,
      "skill": "leq",
      "question": "Supplemental LEQ drill #21 for Period 5.",
      "source": "Archive reference 21",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-022",
      "period": 6,
      "skill": "saq",
      "question": "Supplemental SAQ drill #22 for Period 6.",
      "source": "Archive reference 22",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-023",
      "period": 7,
      "skill": "mcq",
      "question": "Supplemental MCQ drill #23 for Period 7.",
      "source": "Archive reference 23",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-024",
      "period": 8,
      "skill": "dbq",
      "question": "Supplemental DBQ drill #24 for Period 8.",
      "source": "Archive reference 24",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-025",
      "period": 1,
      "skill": "leq",
      "question": "Supplemental LEQ drill #25 for Period 1.",
      "source": "Archive reference 25",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-026",
      "period": 2,
      "skill": "saq",
      "question": "Supplemental SAQ drill #26 for Period 2.",
      "source": "Archive reference 26",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-027",
      "period": 3,
      "skill": "mcq",
      "question": "Supplemental MCQ drill #27 for Period 3.",
      "source": "Archive reference 27",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-028",
      "period": 4,
      "skill": "dbq",
      "question": "Supplemental DBQ drill #28 for Period 4.",
      "source": "Archive reference 28",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-029",
      "period": 5,
      "skill": "leq",
      "question": "Supplemental LEQ drill #29 for Period 5.",
      "source": "Archive reference 29",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-030",
      "period": 6,
      "skill": "saq",
      "question": "Supplemental SAQ drill #30 for Period 6.",
      "source": "Archive reference 30",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-031",
      "period": 7,
      "skill": "mcq",
      "question": "Supplemental MCQ drill #31 for Period 7.",
      "source": "Archive reference 31",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-032",
      "period": 8,
      "skill": "dbq",
      "question": "Supplemental DBQ drill #32 for Period 8.",
      "source": "Archive reference 32",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-033",
      "period": 1,
      "skill": "leq",
      "question": "Supplemental LEQ drill #33 for Period 1.",
      "source": "Archive reference 33",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-034",
      "period": 2,
      "skill": "saq",
      "question": "Supplemental SAQ drill #34 for Period 2.",
      "source": "Archive reference 34",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-035",
      "period": 3,
      "skill": "mcq",
      "question": "Supplemental MCQ drill #35 for Period 3.",
      "source": "Archive reference 35",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-036",
      "period": 4,
      "skill": "dbq",
      "question": "Supplemental DBQ drill #36 for Period 4.",
      "source": "Archive reference 36",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-037",
      "period": 5,
      "skill": "leq",
      "question": "Supplemental LEQ drill #37 for Period 5.",
      "source": "Archive reference 37",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-038",
      "period": 6,
      "skill": "saq",
      "question": "Supplemental SAQ drill #38 for Period 6.",
      "source": "Archive reference 38",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-039",
      "period": 7,
      "skill": "mcq",
      "question": "Supplemental MCQ drill #39 for Period 7.",
      "source": "Archive reference 39",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-040",
      "period": 8,
      "skill": "dbq",
      "question": "Supplemental DBQ drill #40 for Period 8.",
      "source": "Archive reference 40",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-041",
      "period": 1,
      "skill": "leq",
      "question": "Supplemental LEQ drill #41 for Period 1.",
      "source": "Archive reference 41",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-042",
      "period": 2,
      "skill": "saq",
      "question": "Supplemental SAQ drill #42 for Period 2.",
      "source": "Archive reference 42",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-043",
      "period": 3,
      "skill": "mcq",
      "question": "Supplemental MCQ drill #43 for Period 3.",
      "source": "Archive reference 43",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-044",
      "period": 4,
      "skill": "dbq",
      "question": "Supplemental DBQ drill #44 for Period 4.",
      "source": "Archive reference 44",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-045",
      "period": 5,
      "skill": "leq",
      "question": "Supplemental LEQ drill #45 for Period 5.",
      "source": "Archive reference 45",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-046",
      "period": 6,
      "skill": "saq",
      "question": "Supplemental SAQ drill #46 for Period 6.",
      "source": "Archive reference 46",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-047",
      "period": 7,
      "skill": "mcq",
      "question": "Supplemental MCQ drill #47 for Period 7.",
      "source": "Archive reference 47",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-048",
      "period": 8,
      "skill": "dbq",
      "question": "Supplemental DBQ drill #48 for Period 8.",
      "source": "Archive reference 48",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-049",
      "period": 1,
      "skill": "leq",
      "question": "Supplemental LEQ drill #49 for Period 1.",
      "source": "Archive reference 49",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-050",
      "period": 2,
      "skill": "saq",
      "question": "Supplemental SAQ drill #50 for Period 2.",
      "source": "Archive reference 50",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-051",
      "period": 3,
      "skill": "mcq",
      "question": "Supplemental MCQ drill #51 for Period 3.",
      "source": "Archive reference 51",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-052",
      "period": 4,
      "skill": "dbq",
      "question": "Supplemental DBQ drill #52 for Period 4.",
      "source": "Archive reference 52",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-053",
      "period": 5,
      "skill": "leq",
      "question": "Supplemental LEQ drill #53 for Period 5.",
      "source": "Archive reference 53",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-054",
      "period": 6,
      "skill": "saq",
      "question": "Supplemental SAQ drill #54 for Period 6.",
      "source": "Archive reference 54",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-055",
      "period": 7,
      "skill": "mcq",
      "question": "Supplemental MCQ drill #55 for Period 7.",
      "source": "Archive reference 55",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-056",
      "period": 8,
      "skill": "dbq",
      "question": "Supplemental DBQ drill #56 for Period 8.",
      "source": "Archive reference 56",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-057",
      "period": 1,
      "skill": "leq",
      "question": "Supplemental LEQ drill #57 for Period 1.",
      "source": "Archive reference 57",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-058",
      "period": 2,
      "skill": "saq",
      "question": "Supplemental SAQ drill #58 for Period 2.",
      "source": "Archive reference 58",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-059",
      "period": 3,
      "skill": "mcq",
      "question": "Supplemental MCQ drill #59 for Period 3.",
      "source": "Archive reference 59",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-060",
      "period": 4,
      "skill": "dbq",
      "question": "Supplemental DBQ drill #60 for Period 4.",
      "source": "Archive reference 60",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-061",
      "period": 5,
      "skill": "leq",
      "question": "Supplemental LEQ drill #61 for Period 5.",
      "source": "Archive reference 61",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-062",
      "period": 6,
      "skill": "saq",
      "question": "Supplemental SAQ drill #62 for Period 6.",
      "source": "Archive reference 62",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-063",
      "period": 7,
      "skill": "mcq",
      "question": "Supplemental MCQ drill #63 for Period 7.",
      "source": "Archive reference 63",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-064",
      "period": 8,
      "skill": "dbq",
      "question": "Supplemental DBQ drill #64 for Period 8.",
      "source": "Archive reference 64",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-065",
      "period": 1,
      "skill": "leq",
      "question": "Supplemental LEQ drill #65 for Period 1.",
      "source": "Archive reference 65",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-066",
      "period": 2,
      "skill": "saq",
      "question": "Supplemental SAQ drill #66 for Period 2.",
      "source": "Archive reference 66",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-067",
      "period": 3,
      "skill": "mcq",
      "question": "Supplemental MCQ drill #67 for Period 3.",
      "source": "Archive reference 67",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-068",
      "period": 4,
      "skill": "dbq",
      "question": "Supplemental DBQ drill #68 for Period 4.",
      "source": "Archive reference 68",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-069",
      "period": 5,
      "skill": "leq",
      "question": "Supplemental LEQ drill #69 for Period 5.",
      "source": "Archive reference 69",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-070",
      "period": 6,
      "skill": "saq",
      "question": "Supplemental SAQ drill #70 for Period 6.",
      "source": "Archive reference 70",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-071",
      "period": 7,
      "skill": "mcq",
      "question": "Supplemental MCQ drill #71 for Period 7.",
      "source": "Archive reference 71",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-072",
      "period": 8,
      "skill": "dbq",
      "question": "Supplemental DBQ drill #72 for Period 8.",
      "source": "Archive reference 72",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-073",
      "period": 1,
      "skill": "leq",
      "question": "Supplemental LEQ drill #73 for Period 1.",
      "source": "Archive reference 73",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-074",
      "period": 2,
      "skill": "saq",
      "question": "Supplemental SAQ drill #74 for Period 2.",
      "source": "Archive reference 74",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-075",
      "period": 3,
      "skill": "mcq",
      "question": "Supplemental MCQ drill #75 for Period 3.",
      "source": "Archive reference 75",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-076",
      "period": 4,
      "skill": "dbq",
      "question": "Supplemental DBQ drill #76 for Period 4.",
      "source": "Archive reference 76",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-077",
      "period": 5,
      "skill": "leq",
      "question": "Supplemental LEQ drill #77 for Period 5.",
      "source": "Archive reference 77",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-078",
      "period": 6,
      "skill": "saq",
      "question": "Supplemental SAQ drill #78 for Period 6.",
      "source": "Archive reference 78",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-079",
      "period": 7,
      "skill": "mcq",
      "question": "Supplemental MCQ drill #79 for Period 7.",
      "source": "Archive reference 79",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-080",
      "period": 8,
      "skill": "dbq",
      "question": "Supplemental DBQ drill #80 for Period 8.",
      "source": "Archive reference 80",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-081",
      "period": 1,
      "skill": "leq",
      "question": "Supplemental LEQ drill #81 for Period 1.",
      "source": "Archive reference 81",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-082",
      "period": 2,
      "skill": "saq",
      "question": "Supplemental SAQ drill #82 for Period 2.",
      "source": "Archive reference 82",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-083",
      "period": 3,
      "skill": "mcq",
      "question": "Supplemental MCQ drill #83 for Period 3.",
      "source": "Archive reference 83",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-084",
      "period": 4,
      "skill": "dbq",
      "question": "Supplemental DBQ drill #84 for Period 4.",
      "source": "Archive reference 84",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-085",
      "period": 5,
      "skill": "leq",
      "question": "Supplemental LEQ drill #85 for Period 5.",
      "source": "Archive reference 85",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-086",
      "period": 6,
      "skill": "saq",
      "question": "Supplemental SAQ drill #86 for Period 6.",
      "source": "Archive reference 86",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-087",
      "period": 7,
      "skill": "mcq",
      "question": "Supplemental MCQ drill #87 for Period 7.",
      "source": "Archive reference 87",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-088",
      "period": 8,
      "skill": "dbq",
      "question": "Supplemental DBQ drill #88 for Period 8.",
      "source": "Archive reference 88",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-089",
      "period": 1,
      "skill": "leq",
      "question": "Supplemental LEQ drill #89 for Period 1.",
      "source": "Archive reference 89",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-090",
      "period": 2,
      "skill": "saq",
      "question": "Supplemental SAQ drill #90 for Period 2.",
      "source": "Archive reference 90",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-091",
      "period": 3,
      "skill": "mcq",
      "question": "Supplemental MCQ drill #91 for Period 3.",
      "source": "Archive reference 91",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-092",
      "period": 4,
      "skill": "dbq",
      "question": "Supplemental DBQ drill #92 for Period 4.",
      "source": "Archive reference 92",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-093",
      "period": 5,
      "skill": "leq",
      "question": "Supplemental LEQ drill #93 for Period 5.",
      "source": "Archive reference 93",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-094",
      "period": 6,
      "skill": "saq",
      "question": "Supplemental SAQ drill #94 for Period 6.",
      "source": "Archive reference 94",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-095",
      "period": 7,
      "skill": "mcq",
      "question": "Supplemental MCQ drill #95 for Period 7.",
      "source": "Archive reference 95",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-096",
      "period": 8,
      "skill": "dbq",
      "question": "Supplemental DBQ drill #96 for Period 8.",
      "source": "Archive reference 96",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-097",
      "period": 1,
      "skill": "leq",
      "question": "Supplemental LEQ drill #97 for Period 1.",
      "source": "Archive reference 97",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-098",
      "period": 2,
      "skill": "saq",
      "question": "Supplemental SAQ drill #98 for Period 2.",
      "source": "Archive reference 98",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-099",
      "period": 3,
      "skill": "mcq",
      "question": "Supplemental MCQ drill #99 for Period 3.",
      "source": "Archive reference 99",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    },
    {
      "id": "sup-100",
      "period": 4,
      "skill": "dbq",
      "question": "Supplemental DBQ drill #100 for Period 4.",
      "source": "Archive reference 100",
      "sourceType": "Textbook excerpt",
      "answerHint": "Cite specific evidence and connect to the period theme."
    }
  ]
};
